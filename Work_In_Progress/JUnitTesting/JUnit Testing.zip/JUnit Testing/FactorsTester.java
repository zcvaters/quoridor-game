import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class FactorsTester {

	@Test
	void testPerfect1()
	{	
		// TEST 1: should throw the exception because the parameter value is less than 1
		assertThrows(IllegalArgumentException.class, () -> FactorsUtility.perfect(0));
	}
	
	@Test
	void testPerfect2()
	{	
		boolean expected = false;
		
		// TEST 2: should succeed because 1 is a valid parameter value
		assertEquals( expected, FactorsUtility.perfect(1));
	}
	
	@Test
	void testPerfect3()
	{	
		boolean expected = true;
		
		// TEST 3: should succeed because 6 is a valid parameter value
		assertEquals( expected, FactorsUtility.perfect(6));
	}
	
	@Test
	void testPerfect4()
	{	
		boolean expected = false;
		
		// TEST 4: should succeed because 7 is a valid parameter value
		assertEquals( expected, FactorsUtility.perfect(7));
	}

}
